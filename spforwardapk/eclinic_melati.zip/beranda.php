<div class="box box-success">
    <div class="box-header with-border">
        <h3 class="box-title">Home</h3>
    </div>
    <div class="box-body content-custom">
        <p>Selamat Datang di Sistem Pakar dalam Mengidentifikasi Penyakit Kandungan Menggunakan Metode Forward Chaining</p>
        <p>Silahkan pilih menu disamping untuk melakukan pengolahan data</p>
    </div>
</div>